//package com.rubypaper.domain;
//
//import jakarta.persistence.Entity;
//import jakarta.persistence.Id;
//import jakarta.persistence.Table;
//import lombok.Data;
//
//@Data
//@Entity // 이 클래스로부터 생성된 객체를 Entity로 관리해라.(필수)
//@Table(name = "USERS") // 이 클래스로부터 생성된 객체를 BOARD 테이블과 매핑해라.(옵션)
//public class User {
//	@Id 
//	private String id;
//	private String password;
//	private String name;
//	private String role;
//}






