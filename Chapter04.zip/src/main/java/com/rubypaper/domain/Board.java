package com.rubypaper.domain;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.TableGenerator;
import jakarta.persistence.Transient;
import lombok.Data;

@Data
@Entity // 이 클래스로부터 생성된 객체를 Entity로 관리해라.(필수)
@Table(name = "BOARD") // 이 클래스로부터 생성된 객체를 BOARD 테이블과 매핑해라.(옵션)
//@SequenceGenerator(name = "BOARD_SEQ_GENERATOR", 
//                   sequenceName = "BOARD_SEQUENCE", 
//                   initialValue = 1, 
//                   allocationSize = 1)
//@TableGenerator(   name = "BOARD_SEQ_GENERATOR", 
//					 table = "SEQUENCE_GEN", 
//					 pkColumnName = "SEQUENCES",
//					 pkColumnValue = "BOARD",
//					 initialValue = 0, 
//					 allocationSize = 1)
public class Board {
	@Id // seq 변수가 BOARD 테이블의 PK 컬럼(SEQ)과 매핑된다.(필수)
	@GeneratedValue(//generator = "BOARD_SEQ_GENERATOR", 
	                strategy = GenerationType.AUTO) // seq 변수에 자동으로 1부터 1씩 증가된 값을 할당해라.(옵션)
	private int seq;
	
	@Column(nullable = false)
	private String title;
	
	@Column(updatable = false)
	private String writer;
	
	private String content;
	
	@Column(name = "REG_DATE", updatable = false)
//	@Temporal(TemporalType.DATE)
	private Date regDate = new Date(); 
	
	private int cnt = 0;
	
	@Transient
	private String passowrd;
}






