package com.rubypaper.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Service;

import com.rubypaper.domain.Board;
import com.rubypaper.persistence.BoardDAOWithMyBatis;

//@Service
public class BoardServiceWithMyBatis implements ApplicationRunner {

	@Autowired
	private BoardDAOWithMyBatis boardDAO;

	@Override
	public void run(ApplicationArguments args) throws Exception {
//		// 글 등록
//		Board board = new Board();
//		board.setTitle("MyBatis 테스트");
//		board.setWriter("테스터");
//		board.setContent("MyBatis와 Spring 연동 테스트");
//		boardDAO.insertBoard(board);
//		
//		// 글 목록 검색
//		List<Board> boardList = boardDAO.getBoardList();
//		for (Board row : boardList) {
//			System.out.println("---> " + row.toString());
//		}
		
		// 글 상세
		Board board = new Board();
		board.setSeq(1);
		
		Board findBoard = boardDAO.getBoard(board);
		System.out.println(findBoard.getSeq() + "번 게시글 상세 정보");
		System.out.println(findBoard.toString());
	}	
	
}







