package com.rubypaper.service;

import java.util.List;

import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Service;

import com.rubypaper.domain.Board;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;


@Service
public class BoardServiceWithJPA implements ApplicationRunner {
	
//	// merge() 메소드 테스트
//	public void run(ApplicationArguments args) throws Exception {
//		// EntityManagerFactory 생성
//		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Chapter04");
//		
//		// EntityManager(JPA 컨테이너) 생성
//		EntityManager em = emf.createEntityManager();
//		
//		// EntityTransaction 생성
//		EntityTransaction tx = em.getTransaction();
//		
//		// 글 등록
//		tx.begin(); 	// Transaction 시작
//		Board board = new Board();
//		board.setSeq(1);
//		board.setTitle("MyBatis 테스트--수정");
//		board.setWriter("테스터--수정");
//		board.setContent("MyBatis와 Spring 연동 테스트--수정");
//		// JPA 컨테이너에게 Entity를 전달한다.
//		em.merge(board);
//		tx.commit(); 	// Transaction 종료
//		
//		// 자원 해제
//		em.close();
//		emf.close();
//	}	
	
//	// 식별자 값 자동 증가
//	public void run(ApplicationArguments args) throws Exception {
//		// EntityManagerFactory 생성
//		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Chapter04");
//		
//		// EntityManager(JPA 컨테이너) 생성
//		EntityManager em = emf.createEntityManager();
//		
//		// EntityTransaction 생성
//		EntityTransaction tx = em.getTransaction();
//		
//		// 글 등록
//		tx.begin(); 	// Transaction 시작
//
//		for (int i = 1; i <= 5; i++) {
//			Board board = new Board();
//			board.setTitle("MyBatis 테스트-" + i);
//			board.setWriter("테스터-" + i);
//			board.setContent("MyBatis와 Spring 연동 테스트-" + i);
//			em.persist(board);
//		}
//		
//		tx.commit(); 	// Transaction 종료
//		
//		// 자원 해제
//		em.close();
//		emf.close();
//	}
	
//	// 글 목록 검색
//	public void run(ApplicationArguments args) throws Exception {
//		// EntityManagerFactory 생성
//		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Chapter04");
//		
//		// EntityManager(JPA 컨테이너) 생성
//		EntityManager em = emf.createEntityManager();
//			
//		// 글 목록 검색
//		String jpql = "SELECT b FROM Board b ORDER BY b.seq DESC";
//		List<Board> boardList = em.createQuery(jpql).getResultList();
//		System.out.println("[ 게시글 목록 ]");
//		for (Board board : boardList) {
//			System.out.println("---> " + board.toString());
//		}
//		
//		// 자원 해제
//		em.close();
//		emf.close();
//	}
	
//	// 글 삭제
//	public void run(ApplicationArguments args) throws Exception {
//		// EntityManagerFactory 생성
//		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Chapter04");
//		
//		// EntityManager(JPA 컨테이너) 생성
//		EntityManager em = emf.createEntityManager();
//		
//		// EntityTransaction 생성
//		EntityTransaction tx = em.getTransaction();
//		
//		// 글 상세 조회
//		Board findBoard = em.find(Board.class, 1);
//		
//		// 조회한 객체 삭제
//		tx.begin();
//		em.remove(findBoard);
//		tx.commit();
//		
//		// 자원 해제
//		em.close();
//		emf.close();
//	}	
	
//	// 글 수정
//	public void run(ApplicationArguments args) throws Exception {
//		// EntityManagerFactory 생성
//		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Chapter04");
//		
//		// EntityManager(JPA 컨테이너) 생성
//		EntityManager em = emf.createEntityManager();
//		
//		// EntityTransaction 생성
//		EntityTransaction tx = em.getTransaction();
//		
//		// 글 상세 조회
//		Board findBoard = em.find(Board.class, 1);
//		
//		// 조회한 객체 수정
//		tx.begin();
//		findBoard.setTitle("---수정 제목");
//		findBoard.setContent("--- 수정 내용");
//		tx.commit();
//		
//		// 자원 해제
//		em.close();
//		emf.close();
//	}		
	
//	// 글 상세 조회
//	public void run(ApplicationArguments args) throws Exception {
//		// EntityManagerFactory 생성
//		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Chapter04");
//		
//		// EntityManager(JPA 컨테이너) 생성
//		EntityManager em = emf.createEntityManager();
//		
//		// 글 상세 조회
//		Board findBoard = em.find(Board.class, 1);
//		System.out.println(findBoard.getSeq() + "번 게시글 상세 정보");
//		System.out.println(findBoard.toString());
//		
//		// 자원 해제
//		em.close();
//		emf.close();
//	}	

//	// 글 등록
//	public void run(ApplicationArguments args) throws Exception {
//		// EntityManagerFactory 생성
//		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Chapter04");
//		
//		// EntityManager(JPA 컨테이너) 생성
//		EntityManager em = emf.createEntityManager();
//		
//		// EntityTransaction 생성
//		EntityTransaction tx = em.getTransaction();
//		
//		// 글 등록
//		tx.begin(); 	// Transaction 시작
//		Board board = new Board();
//		board.setTitle("MyBatis 테스트");
//		board.setWriter("테스터");
//		board.setContent("MyBatis와 Spring 연동 테스트");
//		// JPA 컨테이너에게 Entity를 전달한다.
//		em.persist(board);
//		tx.commit(); 	// Transaction 종료
//		
//		// 자원 해제
//		em.close();
//		emf.close();
//	}	
	
	// 글 등록
	public void run(ApplicationArguments args) throws Exception {
		// EntityManagerFactory 생성
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Chapter04");
		
		// EntityManager(JPA 컨테이너) 생성
		EntityManager em = emf.createEntityManager();
		
		// EntityTransaction 생성
		EntityTransaction tx = em.getTransaction();
		
		// 글 등록
		tx.begin(); 	// Transaction 시작
		Board board = new Board();
		board.setTitle("MyBatis 테스트");
		board.setWriter("테스터");
		board.setContent("MyBatis와 Spring 연동 테스트");
		// JPA 컨테이너에게 Entity를 전달한다.
		System.out.println("---> 글 등록 요청");
		em.persist(board);
		
		System.out.println("---> commit 전");
		tx.commit(); 	// Transaction 종료
		System.out.println("---> commit 후");
		
		// 자원 해제
		em.close();
		emf.close();
	}	
	
}












