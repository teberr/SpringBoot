package com.rubypaper.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.rubypaper.domain.User;
import com.rubypaper.service.UserService;

import ch.qos.logback.core.model.Model;
import jakarta.servlet.http.HttpSession;

@Controller
public class LoginController {
	
	@Autowired
	private UserService userService;

	// 로그인 화면으로 이동
	@GetMapping("/login")
	public String login() {
		return "login";
	}
	
	// 로그인 인증 처리
	@PostMapping("/login")
	public String login(User user, HttpSession session) {
		User findUser = userService.getUser(user);
		
		// 아이디로 검색한 회원의 비밀 번호 검증
		if(findUser != null && findUser.getPassword().equals(user.getPassword())) {
			// 로그인 성공 시, 세션에 회원 정보 저장
			session.setAttribute("user", findUser);
			
			return "forward:getBoardList";
		} else {
			return "redirect:/";
		}		
	}
	
	// 로그아웃 처리
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		// 로그아웃 요청한 브라우저와 매핑된 세션을 강제 종료한다.
		session.invalidate();
		
		return "redirect:/";
	}
}












