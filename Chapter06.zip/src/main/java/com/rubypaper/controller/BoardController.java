package com.rubypaper.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.rubypaper.domain.Board;
import com.rubypaper.domain.User;
import com.rubypaper.service.BoardService;

import jakarta.servlet.http.HttpSession;

@Controller
public class BoardController {
	
	@Autowired
	private BoardService boardService;
	
	// 글 등록 화면으로 이동
	@GetMapping("/insertBoard")
	public String insertBoard() {
		// insertBoard.jsp 화면으로 이동한다.
		return "insertBoard";
	}
	
	// 글 등록 처리
	@PostMapping("/insertBoard")
	public String insertBoard(Board board) {
		boardService.insertBoard(board);
		return "redirect:getBoardList";
	}
	
	// 글 수정 처리
	@PostMapping("/updateBoard")
	public String updateBoard(Board board) {
		boardService.updateBoard(board);
		return "forward:getBoardList";
	}
	
	// 글 삭제 처리
	@GetMapping("/deleteBoard")
	public String deleteBoard(Board board) {
		boardService.deleteBoard(board);
		return "forward:getBoardList";
	}

	// 글 상세 조회 처리
	@GetMapping("/getBoard")
	public String getBoard(Board board, Model model) {		
		model.addAttribute("board", boardService.getBoard(board));
		return "getBoard";
	}
	
	// 글 목록 검색 처리
	@RequestMapping("/getBoardList")
	public String getBoardList(Model model, HttpSession session) {	
		// 세션에 user 정보가 등록되지 않은 상태면 인증에 성공하지 못한 것으로 판단한다.
		User user = (User) session.getAttribute("user");
		if(user == null) {
			return "redirect:login";
		} else {		
			// 검색 결과를 JSP 파일에서 사용할 수 있도록 Model에 등록한다.
			model.addAttribute("boardList", boardService.getBoardList());
			
			// getBoardList.jsp 화면으로 이동한다.
			return "getBoardList";
		}
	}
}




