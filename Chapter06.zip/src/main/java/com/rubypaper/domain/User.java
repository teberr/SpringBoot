package com.rubypaper.domain;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Data
@Entity 
@Table(name = "USERS")
public class User {
	@Id
	private String username;	// 인증에 사용할 ID다.
	private String password;	
	private String name;		// 사용자 이름이다.
	private String role;
}






