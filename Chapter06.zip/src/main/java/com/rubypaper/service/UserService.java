package com.rubypaper.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rubypaper.domain.User;
import com.rubypaper.persistence.UserRepository;

@Service
public class UserService {

	@Autowired
	private UserRepository userRepository;
	
	public User getUser(User user) {
		Optional<User> findObject = userRepository.findById(user.getUsername());
		if(findObject.isPresent()) {
			return findObject.get();
		} else {
			return null;
		}
	}
}
