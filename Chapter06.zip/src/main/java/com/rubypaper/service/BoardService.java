package com.rubypaper.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rubypaper.domain.Board;
import com.rubypaper.persistence.BoardRepository;

@Service
public class BoardService {

	@Autowired
	private BoardRepository boardRepository;
	
	public void insertBoard(Board board) {
		boardRepository.save(board);
	}
	
	public void updateBoard(Board board) {
		// 수정할 엔티티를 검색한다. 그래야 해당 엔티티가 JPA 1차 캐시에 등록되니까
		Board findBoard = boardRepository.findById(board.getSeq()).get();
		
		// 엔티티 수정
		findBoard.setTitle(board.getTitle());
		findBoard.setContent(board.getContent());
		boardRepository.save(findBoard);		
	}
	
	public void deleteBoard(Board board) {
		boardRepository.deleteById(board.getSeq());
	}
	
	public Board getBoard(Board board) {
		return boardRepository.findById(board.getSeq()).get();
	}
	
	public List<Board> getBoardList() {
		return boardRepository.findAll();
	}
}
