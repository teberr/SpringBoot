package com.rubypaper;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.querydsl.core.BooleanBuilder;
import com.rubypaper.domain.Board;
import com.rubypaper.domain.QBoard;
import com.rubypaper.persistence.BoardRepository;
import com.rubypaper.persistence.BoardRepositoryQueryDSL;

@SpringBootTest
class QueryMethodTest {
	
	@Autowired
	private BoardRepository boardRepository;
	
	@Autowired
	private BoardRepositoryQueryDSL boardRepositoryQueryDSL;
	
	@Test
	void testQueryDSL() {
		BooleanBuilder builder = new BooleanBuilder();
		
		// 검색 설정
		String condition = "content";
		String keyword = "10";
		
		QBoard qboard = QBoard.board; // QBoard 객체를 얻는다.
		if(condition.equals("title")) {
			builder.and(qboard.title.like("%" + keyword + "%"));
		} else if(condition.equals("content")) {
			builder.and(qboard.content.like("%" + keyword + "%"));
		}
		
		// 페이징 처리
		Pageable pageable = PageRequest.of(0, 5);
		Iterable<Board> boardList = boardRepositoryQueryDSL.findAll(builder, pageable);
		System.out.println("[ 검색 결과 ]");
		for (Board board : boardList) {
			System.out.println("---> " + board.toString());
		}
	}
	
	//@Test
	void testQueryAnnotation() {
		List<Object[]> boardList = boardRepository.getBoardList("목-17");
		
		System.out.println("[ 검색 결과 ]");
		for (Object[] board : boardList) {
			System.out.println("---> " + Arrays.toString(board));
		}
	}
	
	//@Test
	void testQueryMethod() {
		// 첫 번째 페이지(0)에 해당하는 5건의 데이터만 가져와라. 
		Pageable pageable = PageRequest.of(1, 5, Sort.Direction.DESC, "seq"); 
		
		Page<Board> pageInfo = boardRepository.findByTitleContaining("17", pageable);
		List<Board> boardList = pageInfo.getContent();
		
		System.out.println("[ 검색된 글 목록 ]");
		for (Board board : boardList) {
			System.out.println("---> " + board.toString());
		}
		
		// 페이지 정보 추출
		System.out.println("검색된 전체 데이터 수 : " + pageInfo.getTotalElements());
		System.out.println("전체 페이지 수 : " + pageInfo.getTotalPages());
		System.out.println("한 페이지에 출력할 데이터 수 : " + pageInfo.getSize());
		
		if(pageInfo.hasPrevious()) {
			System.out.println("이전 페이지 정보 : " + pageInfo.previousPageable());
		}
		
		System.out.println("현재 페이지 정보 : " + pageInfo.getPageable());
		
		if(pageInfo.hasNext()) {
			System.out.println("다음 페이지 정보 : " + pageInfo.nextPageable());
		}
	}
	
	//@BeforeEach
	void initData() {
		for (int i = 1; i <= 200; i++) {
			Board board = new Board();
			board.setTitle("테스트 제목-" + i);
//			board.setWriter("테스터");
			board.setContent("테스트 내용-" + i);	
			boardRepository.save(board);
		}
	}

}
