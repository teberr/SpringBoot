package com.rubypaper;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.rubypaper.domain.Board;
import com.rubypaper.domain.User;
import com.rubypaper.persistence.BoardRepository;
import com.rubypaper.persistence.UserRepository;

@SpringBootTest
class ManyToOneBothSideRelationMappingTest {
	
	@Autowired
	private BoardRepository boardRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	@Test
	void testCascade() {
		// user01 회원 정보를 삭제한다. 
		userRepository.deleteById("user01");
	}
	
	//@Test
	void testMethod() {
		// 하나의 회원(User)을 검색하여 연관된 게시글(Board) 정보를 사용한다. 
		User findUser = userRepository.findById("user01").get();
		System.out.println("[ " + findUser.getName() + "가 등록한 게시글 목록 ]");
		List<Board> boardList = findUser.getBoardList();
		for (Board board : boardList) {
			System.out.println("---> " + board.toString());
		}
	}
	
	//@Test
	void testInsertBoard() {
		// 회원 등록
		User user1 = new User();
		user1.setId("user01");
		user1.setName("둘리");
		userRepository.save(user1);
		
		User user2 = new User();
		user2.setId("user02");
		user2.setName("도우너");
		userRepository.save(user2);
		
		// 게시글 등록
		for (int i = 1; i <= 3; i++) {
			Board board = new Board();
			board.setTitle("둘리가 등록한 게시글-" + i);
			board.setContent("둘리가 등록한 게시글입니다.");
			board.setUser(user1);
			boardRepository.save(board);
		}
		
		for (int i = 1; i <= 3; i++) {
			Board board = new Board();
			board.setTitle("도우너가 등록한 게시글-" + i);
			board.setContent("도우너가 등록한 게시글입니다.");	
			board.setUser(user2);
			boardRepository.save(board);
		}
	}

}
