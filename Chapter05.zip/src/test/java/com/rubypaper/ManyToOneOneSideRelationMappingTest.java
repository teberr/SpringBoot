package com.rubypaper;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.rubypaper.domain.Board;
import com.rubypaper.domain.User;
import com.rubypaper.persistence.BoardRepository;
import com.rubypaper.persistence.UserRepository;

@SpringBootTest
class ManyToOneOneSideRelationMappingTest {
	
	@Autowired
	private BoardRepository boardRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	@Test
	void testMethod() {
		// 하나의 게시글(Board)를 검색하여 연관된 회원(User) 정보를 사용한다. 
		Board findBoard = boardRepository.findById(1).get();
		System.out.println("[ " + findBoard.getSeq() + "번 게시글 정보 ]");
		System.out.println("제목 : " + findBoard.getTitle());
		System.out.println("작성자 : " + findBoard.getUser().getName());
	}
	
	//@Test
	void testInsertBoard() {
		// 회원 등록
		User user1 = new User();
		user1.setId("user01");
		user1.setName("둘리");
		userRepository.save(user1);
		
		User user2 = new User();
		user2.setId("user02");
		user2.setName("도우너");
		userRepository.save(user2);
		
		// 게시글 등록
		for (int i = 1; i <= 3; i++) {
			Board board = new Board();
			board.setTitle("둘리가 등록한 게시글-" + i);
			board.setContent("둘리가 등록한 게시글입니다.");
			board.setUser(user1);
			boardRepository.save(board);
		}
		
		for (int i = 1; i <= 3; i++) {
			Board board = new Board();
			board.setTitle("도우너가 등록한 게시글-" + i);
			board.setContent("도우너가 등록한 게시글입니다.");	
			board.setUser(user2);
			boardRepository.save(board);
		}
	}

}
