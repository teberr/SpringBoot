package com.rubypaper;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.rubypaper.domain.Board;
import com.rubypaper.persistence.BoardRepository;

@SpringBootTest
class BoardRepositoryTest {
	
	@Autowired
	private BoardRepository boardRepository;
	
//	@Test
//	void testGetBoardList() {
//		List<Board> boardList = boardRepository.getBoardList("정2");
//		System.out.println("[ 검색된 글 목록 ]");
//		for (Board board : boardList) {
//			System.out.println("---> " + board.toString());
//		}
//	}
	
	//@Test
	void testDeleteBoard() {
		boardRepository.deleteById(1);
	}
	
	//@Test
	void testUpdateBoard() {
		Board findBoard = boardRepository.findById(1).get();
//		board.setSeq(1);
		findBoard.setTitle("--- 제목 수정2");
		findBoard.setContent("--- 내용 수정2");	
		// save()는 merge()와 동일한 메소드다.
		boardRepository.save(findBoard);
	}
	
	//@Test
	void testGetBoard() {
		Board findBoard = boardRepository.findById(1).get();
		System.out.println("검색 결과 : " + findBoard.toString());
		
//		if(findObject.isPresent()) {
//			Board findBoard = findObject.get();
//			System.out.println("검색 결과 : " + findBoard.toString());
//		} else {
//			System.out.println("검색 결과 없음");
//		}
	}

	//@Test
	void testInsertBoard() {
		Board board = new Board();
		board.setTitle("Data-JPA 테스트");
//		board.setWriter("테스터");
		board.setContent("Data-JPA 테스트 중입니다.");	
		// save()는 merge()와 동일한 메소드다.
		boardRepository.save(board);
	}

}
