package com.rubypaper.persistence;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.rubypaper.domain.Board;

// 개발자가 JpaRepository를 상속한 인터페이스를 정의하면 Spring 컨테이너가 구현 클래스를 만들고 객체 생성도 해준다.
public interface BoardRepository extends JpaRepository<Board, Integer> {
	// 쿼리 메소드 사용하기
	// SELECT b FROM Board AS b WHERE b.title = %?1%
	List<Board> findByTitle(String searchKeyword);	
	
	// SELECT b FROM Board AS b WHERE b.title LIKE %?1%
	List<Board> findByTitleContaining(String searchKeyword);
	
	List<Board> findByTitleContainingOrContentContaining(String title, String content);
	
	List<Board> findByTitleContainingOrderBySeqDesc(String searchKeyword);
	
	// 페이징 처리
	//List<Board> findByTitleContaining(String searchKeyword, Pageable pageable);
	
	Page<Board> findByTitleContaining(String searchKeyword, Pageable pageable);
	
	// JPQL 직접 사용하기
//	@Query("SELECT b FROM Board AS b WHERE b.title LIKE %:keyword% ORDER BY b.seq DESC")
//	List<Board> getBoardList(@Param("keyword") String searchKeyword);
	
//	@Query("SELECT b.seq, b.title, b.content FROM Board AS b WHERE b.title LIKE %:keyword% ORDER BY b.seq DESC")
//	List<Object[]> getBoardList(@Param("keyword") String searchKeyword);
	
	@Query(value = "SELECT SEQ, TITLE, CONTENT, REG_DATE FROM BOARD WHERE TITLE LIKE %:keyword% ORDER BY SEQ DESC", 
		   nativeQuery = true)
	List<Object[]> getBoardList(@Param("keyword") String searchKeyword);

}









