package com.rubypaper.persistence;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rubypaper.domain.User;

// 개발자가 JpaRepository를 상속한 인터페이스를 정의하면 Spring 컨테이너가 구현 클래스를 만들고 객체 생성도 해준다.
public interface UserRepository extends JpaRepository<User, String> {

}









