package com.rubypaper.domain;

import java.util.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;
import lombok.ToString;

@Data
@ToString(exclude = "user")
@Entity 
public class Board {
	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int seq;
	
	@Column(nullable = false)
	private String title;
	
//	@Column(updatable = false)
//	private String writer;
	
	private String content;
	
	@Column(name = "REG_DATE", updatable = false)
	private Date regDate = new Date(); 
	
	private int cnt = 0;
	
	@ManyToOne(fetch = FetchType.EAGER, optional = false) // 다대일 관계 매핑
	// 1. BOARD 테이블에 조인에 사용할 USER_ID(외래 키) 컬럼을 추가해라.
	// 2. USER_ID 컬럼에 user 변수가 참조하는 User 객체의 식별자 변수(PK 컬럼과 매핑되는)값을 저장해라.
	@JoinColumn(name = "USER_ID")
	private User user;
}


















