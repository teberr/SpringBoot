package com.rubypaper.junit4;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.rubypaper.junit.MyCalc;

public class MyCalcTest {
	private MyCalc calc;

	@Before
	public void init() throws Exception {
		calc = new MyCalc(10, 3);
	}

	@After
	public void destroy() throws Exception {
		calc = null;
	}

	@Test
	public void 플러스() {
		assertEquals(13, calc.plus());
	}

	@Test
	public void 마이너스() {
		assertEquals(7, calc.minus());
	}

}
