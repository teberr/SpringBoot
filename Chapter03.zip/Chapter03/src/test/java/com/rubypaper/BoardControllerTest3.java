package com.rubypaper;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;

import com.rubypaper.domain.BoardVO;

// 1. @SpringBootTest는 모든 유형의 객체를 생성한다. 
// 2. @SpringBootTest 서블릿 컨테이너를 Mocking하지 않는다.
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
public class BoardControllerTest3 {
	
	// TestRestTemplate은 가짜 웹브라우저다.
	@Autowired
	private TestRestTemplate restTemplate;
	
	@Test
	public void testHello() throws Exception {
		// HTTP 요청
		String result = restTemplate.getForObject("/hello.do?name=gurum", String.class);
		
		// 응답 결과 검증
		assertEquals("hello : gurum", result);
	}
	
	@Test
	public void testGetBoard() throws Exception {
		// HTTP 요청
		BoardVO result = restTemplate.getForObject("/getBoard.do", BoardVO.class);
		
		// 응답 결과 검증
		assertNotNull(result); // 리턴 결과가 있나?
		assertEquals("테스터", result.getWriter()); // 작성자가 채규태인가?
	}
	
	@Test
	public void testGetBoardList() throws Exception {
		// HTTP 요청
		List<BoardVO> result = restTemplate.getForObject("/getBoardList.do", List.class);
		
		// 응답 결과 검증
		assertEquals(5, result.size());
	}
}








