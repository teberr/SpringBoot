package com.rubypaper;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;

// 1. 사용자가 정의한 클래스(@Repository, @Service, @Controller)의 객체를 생성한다.
// 2. 테스트에 필요한 모든 객체를 자동 설정 클래스로 생성한다. 
@SpringBootTest(properties = {"author.name=CHAE", 
		                      "author.nation=KOREA"})
public class PropertyTest {
	
//	@Value("${author.name}")
//	private String name;
//	
//	@Value("${author.age}")
//	private int age;	
	
	@Autowired
	private Environment env;
	
	@Test
	public void testing() {
		System.out.println("이름 : " + env.getProperty("author.name"));
		System.out.println("나이 : " + env.getProperty("author.age"));
		System.out.println("국적 : " + env.getProperty("author.nation"));
	}
}
