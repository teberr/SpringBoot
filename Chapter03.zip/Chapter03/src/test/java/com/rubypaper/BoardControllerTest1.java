package com.rubypaper;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;

import com.rubypaper.controller.BoardController;
import com.rubypaper.persistence.BoardDAO;
import com.rubypaper.service.BoardService;

// @SpringBootTest는 사용자가 정의한 클래스(@Repository, @Service, @Controller)의 객체를 생성한다.
@SpringBootTest(classes = {BoardController.class})
public class BoardControllerTest1 {
	
	@Test
	public void testing() {
		System.out.println("test...");
		
	}
}
