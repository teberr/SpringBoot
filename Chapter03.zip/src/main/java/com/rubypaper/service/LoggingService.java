package com.rubypaper.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Service;

@Service
public class LoggingService implements ApplicationRunner {
	// 로거 객체 획득
	private Logger logger = LoggerFactory.getLogger(LoggingService.class);

	@Override
	public void run(ApplicationArguments args) throws Exception {
		// 로그 레벨별 로그 출력
		logger.trace("trace 레벨 로그");
		logger.debug("debug 레벨 로그");
		logger.info("info 레벨 로그");
		logger.warn("warn 레벨 로그");
		logger.error("error 레벨 로그");		
	}	

}
