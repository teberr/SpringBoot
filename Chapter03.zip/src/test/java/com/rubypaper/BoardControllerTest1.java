package com.rubypaper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import com.rubypaper.controller.BoardController;

// @SpringBootTest는 사용자가 정의한 클래스(@Repository, @Service, @Controller)의 객체를 생성한다.
@SpringBootTest(classes = { BoardController.class })
public class BoardControllerTest1 {

	@Test
	public void testing() {
		System.out.println("test...");
	}
}
