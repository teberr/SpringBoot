package com.rubypaper.domain;

public enum Role {
	ADMIN, MANAGER, MEMBER
}
