package com.rubypaper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.rubypaper.domain.User;
import com.rubypaper.persistence.UserRepository;

// UserDetailsService 인터페이스를 구현한 객체가 먼저 메모리에 생성되면 
// 자동설정에 의해서 생성되던 UserDetailsService 구현 객체는 더 이상 생성되지 않는다.
@Service
public class UserDetailsServiceImpl implements UserDetailsService {
	
	@Autowired
	private UserRepository userRepository;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		// 사용자가 입력한 아이디(username)로 회원을 조회한다. 
		User findUser = userRepository.findById(username).get();
		if(findUser == null) {
			// 검색된 회원이 없으면 예외로 처리
			throw new UsernameNotFoundException(username + "회원이 존재하지 않습니다.");
		}
		
		// 검색된 회원 정보를 바탕으로 UserDetails 타입의 객체를 생성하여 리턴한다.
		return new org.springframework.security.core.userdetails.User(
				findUser.getUsername(), 
				findUser.getPassword(), 
				AuthorityUtils.createAuthorityList("ROLE_" + findUser.getRole().toString()));
	}

}
