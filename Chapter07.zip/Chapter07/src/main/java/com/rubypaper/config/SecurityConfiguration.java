package com.rubypaper.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity // 이제부터 스프링 시큐리티를 커스터마이징 할 거라는 선언
public class SecurityConfiguration {
	
	// 내가 만든 UserDetailsServiceImpl 객체를 주입한다.
	@Autowired
	private UserDetailsService userDetailsService;
	
	@Bean
	PasswordEncoder passwordEncoder() {
		return PasswordEncoderFactories.createDelegatingPasswordEncoder();
	}

	@Bean
	SecurityFilterChain filterChain(HttpSecurity security) throws Exception {			
		// 브라우저로부터 CSRF 토큰을 받지않겠다는 설정
		security.csrf(csrf -> csrf.disable());
		
		// 인증과 인가 설정	
		security.authorizeHttpRequests(authorize -> authorize
				// 요청 경로에 member가 포함되어있다면 인증에 성공해야 한다. 
				.requestMatchers(new AntPathRequestMatcher("/member/**")).authenticated()
				// 요청 경로에 manager가 포함되어있다면 인증에 성공하고 권한이 MANAGER여야 한다. 
		        .requestMatchers(new AntPathRequestMatcher("/manager/**")).hasRole("MANAGER")
                .requestMatchers(new AntPathRequestMatcher("/admin/**")).hasRole("ADMIN")
                // 위에서 언급한 경로 외에 나머지 경로는 인증 없이 접근 가능
                .anyRequest().permitAll());
		
		// 로그인 화면 설정
		security.formLogin(login -> login
				.loginPage("/login")
				// 로그인 성공하면 자동으로 success 페이지를 요청하도록 설정
				.defaultSuccessUrl("/success", true));
		
		// 권한 에러 페이지 설정
		security.exceptionHandling(exception -> exception
				// 권한이 없는 경로를 요청했을 때, denied 페이지를 요청하도록 설정
				.accessDeniedPage("/denied"));
		
		// 로그아웃 설정
		security.logout(logout -> logout
				.invalidateHttpSession(true)
				.logoutSuccessUrl("/"));
		
		// 내가 만든 UserDetailsServiceImpl 객체를 적용한다.
		security.userDetailsService(userDetailsService);
		
		return security.build();
	}
	
//	@Autowired
//	void authenticate(AuthenticationManagerBuilder auth) throws Exception {
//		// 메모리에 두 개의 계정을 생성한다.
//		auth.inMemoryAuthentication()
//		.withUser("mmm").password("{noop}mmm111").roles("MANAGER")
//		.and()
//		.withUser("aaa").password("{noop}aaa222").roles("ADMIN");
//	}
}







