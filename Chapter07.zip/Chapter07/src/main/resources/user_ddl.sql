drop table users;

create table users(
	username varchar2(10) primary key, -- 반드시 ID는 username으로 한다.
	password varchar2(100), -- 비밀번호는 암호화해서 저장해야 하므로 충분히 길게 잡는다.
	name varchar2(50),
	role varchar2(12),
	enabled boolean	
);

insert into users values('mmm', 'mmm111', '매니저', 'MANAGER', true);
insert into users values('aaa', 'aaa111', '어드민', 'ADMIN', true);